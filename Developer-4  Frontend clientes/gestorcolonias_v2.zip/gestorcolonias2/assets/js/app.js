// ══════════════════════════════════════
//  assets/js/app.js — AgroGestor GT
// ══════════════════════════════════════

// ════════════════════════════════════
//  MODO OSCURO / CLARO
//  Guarda la preferencia en una cookie
// ════════════════════════════════════
function toggleModo() {
    const html    = document.documentElement;
    const actual  = html.getAttribute('data-modo') || 'dark';
    const nuevo   = actual === 'dark' ? 'light' : 'dark';

    // Aplicar al HTML
    html.setAttribute('data-modo', nuevo);

    // Actualizar botón
    const icono = document.getElementById('modoIcono');
    const texto = document.getElementById('modoTexto');
    if (icono) icono.textContent = nuevo === 'dark' ? '☀️' : '🌙';
    if (texto) texto.textContent = nuevo === 'dark' ? 'Modo Claro' : 'Modo Oscuro';

    // Guardar en cookie (dura 1 año)
    const expiry = new Date();
    expiry.setFullYear(expiry.getFullYear() + 1);
    document.cookie = 'modo=' + nuevo + '; expires=' + expiry.toUTCString() + '; path=/; SameSite=Lax';

    // Toast informativo
    toast(nuevo === 'dark' ? '🌙 Modo oscuro activado' : '☀️ Modo claro activado', 'success');
}

// ════════════════════════════════════
//  TOAST NOTIFICATIONS
// ════════════════════════════════════
function toast(msg, type = 'success') {
    const container = document.getElementById('toasts');
    if (!container) return;

    const t = document.createElement('div');
    t.className = 'toast ' + type;
    t.textContent = msg;
    container.appendChild(t);

    // Auto eliminar después de 3.5s
    setTimeout(() => {
        t.style.opacity = '0';
        t.style.transform = 'translateX(50px)';
        t.style.transition = 'all .3s ease';
        setTimeout(() => t.remove(), 300);
    }, 3500);
}

// ════════════════════════════════════
//  MOSTRAR ALERTAS PHP COMO TOAST
// ════════════════════════════════════
document.addEventListener('DOMContentLoaded', function () {

    // Mostrar alerta PHP como toast y ocultarla del DOM
    const alert = document.querySelector('.alert');
    if (alert) {
        const type = alert.classList.contains('alert-success') ? 'success' : 'error';
        // Esperar 300ms para que se vea el toast después de cargar
        setTimeout(() => {
            toast(alert.textContent.trim(), type);
        }, 300);
        // Ocultar el alert de pantalla (opcional: comentar si prefieres verlo)
        // alert.style.display = 'none';
    }

    // ════════════════════════════════
    //  INPUT: solo números en teléfono (8 dígitos Guatemala)
    // ════════════════════════════════
    const tel = document.getElementById('cli_telefono');
    if (tel) {
        tel.addEventListener('input', function () {
            this.value = this.value.replace(/\D/g, '').slice(0, 8);
        });
        tel.addEventListener('keypress', function (e) {
            if (!/\d/.test(e.key)) e.preventDefault();
        });
    }

    // ════════════════════════════════
    //  INPUT: solo números en Código Postal (5 dígitos)
    // ════════════════════════════════
    const cp = document.getElementById('col_cp');
    if (cp) {
        cp.addEventListener('input', function () {
            this.value = this.value.replace(/\D/g, '').slice(0, 5);
        });
        cp.addEventListener('keypress', function (e) {
            if (!/\d/.test(e.key)) e.preventDefault();
        });
    }

    // ════════════════════════════════
    //  Confirmación antes de enviar formularios de eliminación
    // ════════════════════════════════
    document.querySelectorAll('a.btn-danger').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            // Si el href tiene ?eliminar= pedimos confirmación adicional desde el onclick inline
            // Este listener es solo como refuerzo
        });
    });

    // ════════════════════════════════
    //  Auto-cerrar alertas después de 5s
    // ════════════════════════════════
    const alertBox = document.querySelector('.alert');
    if (alertBox) {
        setTimeout(() => {
            alertBox.style.transition = 'opacity .5s ease';
            alertBox.style.opacity = '0';
            setTimeout(() => alertBox.remove(), 500);
        }, 5000);
    }

});
