<?php
// ══════════════════════════════════════
//  includes/header.php
// ══════════════════════════════════════

// Leer modo desde cookie (dark por defecto)
$modo = isset($_COOKIE['modo']) && $_COOKIE['modo'] === 'light' ? 'light' : 'dark';

$pagina_actual = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="es" data-modo="<?= $modo ?>">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>AgroGestor GT — <?= htmlspecialchars($titulo_pagina ?? 'Sistema') ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,400&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="assets/css/styles.css"/>
</head>
<body>

<!-- ══ Sidebar ══ -->
<aside class="sidebar">

  <div class="logo">Agro<span>Gestor</span><em>GT</em></div>

  <nav>
    <a href="index.php"          class="<?= $pagina_actual === 'index'          ? 'active' : '' ?>">
      <span class="ico">⬡</span> Dashboard
    </a>
    <a href="form_colonia.php"   class="<?= $pagina_actual === 'form_colonia'   ? 'active' : '' ?>">
      <span class="ico">🏘</span> Registrar Colonia
    </a>
    <a href="form_cliente.php"   class="<?= $pagina_actual === 'form_cliente'   ? 'active' : '' ?>">
      <span class="ico">👤</span> Registrar Cliente
    </a>
    <a href="lista_clientes.php" class="<?= $pagina_actual === 'lista_clientes' ? 'active' : '' ?>">
      <span class="ico">📋</span> Lista de Clientes
    </a>
  </nav>

  <!-- Botón modo oscuro / claro -->
  <div class="modo-toggle">
    <button id="btnModo" onclick="toggleModo()" title="Cambiar modo">
      <span id="modoIcono"><?= $modo === 'dark' ? '☀️' : '🌙' ?></span>
      <span id="modoTexto"><?= $modo === 'dark' ? 'Modo Claro' : 'Modo Oscuro' ?></span>
    </button>
  </div>

  <div class="sidebar-footer">v2.0 · AgroGestor GT</div>
</aside>

<!-- ══ Main ══ -->
<main class="main">
