<?php
// ══════════════════════════════════════
//  includes/db.php
//  Conexión a MySQL — 3GoogieHost
//  ↓ Edita estos 4 valores con los de tu panel ↓
// ══════════════════════════════════════

define('DB_HOST',    'localhost');       // Siempre localhost en 3GoogieHost
define('DB_USER',    'tu_usuario');      // Usuario de tu BD en el panel
define('DB_PASS',    'tu_password');     // Contraseña de tu BD
define('DB_NAME',    'tu_basededatos'); // Nombre de tu base de datos
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST
             . ';dbname='    . DB_NAME
             . ';charset='   . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die('<div style="font-family:sans-serif;padding:40px;color:#A62F03">
                 <h2>❌ Error de conexión a la base de datos</h2>
                 <p>' . htmlspecialchars($e->getMessage()) . '</p>
                 <p>Revisa los datos en <code>includes/db.php</code></p>
                 </div>');
        }
    }
    return $pdo;
}
?>
