<?php
// ══════════════════════════════════════
//  includes/footer.php
// ══════════════════════════════════════
?>
</main><!-- /main -->

<div class="toast-container" id="toasts"></div>

<script src="assets/js/app.js"></script>
</body>
</html>
